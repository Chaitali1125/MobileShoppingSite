export class Product{
    id:number=0;
    artist:string='';
    category:string='';
    description:string='';
    image:any;
    image_type:string='';
    name:string='';
    price:number=0;
    status:string='';  
  
    product(){}
  
  }  
  