export class UserRegistration {
    name:string='';
	email:string='';
	password:string='';  
	phone:number=0;
	dob:Date=new Date;
	role:string='';
	apartment:string='';
	street:string='';
	city:string='';
	state:string='';
	country:string='';
	pin:number=0;
	UserRegistration(){}
	// constructor(public name: string,public email: string,public password: string,public phone: string,
	// 	public dob: Date,public role: string,public apartment: string,public street: string,public city: string,
	// 	public state: string,public country: string,public pin: number){}
} 