export class Wallet {
    id:number=0;
    amount:any=0;
    Wallet(){}
}
