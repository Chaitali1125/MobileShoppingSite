export class AddProduct {
    name: string = "";
    category: string = "";
    price: Number = 0;
    description: string = "";
    AddProduct(){}
}
