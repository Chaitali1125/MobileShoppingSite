export class Login {
    userName: string="";
    password: string="";
    UserRegistration(){}
    // constructor(public userName: string, public password: string) { }
}
